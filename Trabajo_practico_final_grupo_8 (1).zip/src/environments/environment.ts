// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBwQd_QpHzWGq75ZbQPhr2yY5dSRw8GpQQ",
  authDomain: "storage-para-probar.firebaseapp.com",
  projectId: "storage-para-probar",
  storageBucket: "storage-para-probar.firebasestorage.app",
  messagingSenderId: "837726352847",
  appId: "1:837726352847:web:81817437acad12d5ef8eba"
  }
};

// Initialize Firebase
